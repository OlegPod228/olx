from django.contrib import admin
from .models import Product, CardData, Transition, Chat
# Register your models here.

admin.site.register(Product)
admin.site.register(CardData)
admin.site.register(Transition)
admin.site.register(Chat)