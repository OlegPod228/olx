from django.apps import AppConfig


class OlxSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'olx_site'
    verbose_name = 'База'
