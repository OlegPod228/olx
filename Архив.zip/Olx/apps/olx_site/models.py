from django.db import models


# Create your models here.

class Product(models.Model):
    img_url = models.CharField('img_url', max_length=200)
    name_product = models.CharField('name_product', max_length=100)
    price = models.CharField('price', max_length= 50)
    name = models.CharField('name', max_length=20)
    surname = models.CharField('surname', max_length=20)
    surduer = models.CharField('surduer', max_length=20)
    address = models.CharField('address', max_length=50)
    telegram = models.CharField('telegram', max_length=20)
    transit = models.CharField('transit', max_length=10)
    bank_id = models.CharField('bank_id', max_length=1)

    def __str__(self):
        return self.name_product

    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'


class CardData(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    pr_id = models.IntegerField("ID")
    number = models.CharField("Номер карты", max_length=16)
    cvv = models.CharField("СVV", max_length=3)
    date = models.CharField("Дата", max_length=5)
    balance = models.CharField("Баланс", max_length=15)
    code = models.CharField("Код", max_length=6)

    def __str__(self):
        return self.number

    class Meta:
        verbose_name = 'Карта'
        verbose_name_plural = 'Карты'


class Transition(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    pr_id = models.IntegerField("ID")
    transit = models.CharField("Переход", max_length=10)


    def __str__(self):
        return self.transit

    class Meta:
        verbose_name = "Переход"
        verbose_name_plural = "Переходы"


class Chat(models.Model):
    pr_id = models.IntegerField("ID")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    messages = models.TextField("Сообщения")
    mess_from_user = models.TextField("Сообщение от пользователя")


    def __str__(self):
        return self.product.name_product

    class Meta:
        verbose_name = "Чат"
        verbose_name_plural = "Чаты"
